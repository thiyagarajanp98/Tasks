package com.batch.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.batch.model.ErrorInfo;
import com.batch.model.Person;
import com.batch.model.PersonError;
import com.batch.repository.ErrorInfoRepo;
import com.batch.repository.PersonErrorRepo;

public class PersonItemProcessor implements ItemProcessor<Person, Person>{

	private static final Logger log= LoggerFactory.getLogger(PersonItemProcessor.class);
	@Autowired
	PersonErrorRepo personErrorRepo;
	@Autowired
	ErrorInfoRepo errorInfoRepo;
	@Override
	public Person process(Person item) throws Exception {
		log.info("Processor Started");
		String firstName="";
		String lastName="";
		String age="";
		String gender="";
		if(item.getFirstName().matches("^[a-zA-Z]*$"))
		{
			firstName+=item.getFirstName().toUpperCase();
		}
		else
		{
			PersonError details=personErrorRepo.findByColumnName("FirstName");
			ErrorInfo error=new ErrorInfo(item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		if(item.getLastName().matches("^[a-zA-Z]*$"))
		{
			lastName+=item.getLastName().toUpperCase();
		}
		else
		{
			PersonError details=personErrorRepo.findByColumnName("LastName");
			ErrorInfo error=new ErrorInfo( item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		if(item.getAge().matches("^[0-9]*$"))
		{
			age+=item.getAge();
		}
		else
		{
			PersonError details=personErrorRepo.findByColumnName("Age");
			ErrorInfo error=new ErrorInfo(item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		if(item.getGender().equals("MALE")||item.getGender().equals("male")||item.getGender().equals("Male")||item.getGender().equals("FEMALE")||item.getGender().equals("Female")||item.getGender().equals("female"))
		{
			gender+=item.getGender().toUpperCase();
		}
		else
		{
			PersonError details=personErrorRepo.findByColumnName("Gender");
			ErrorInfo error=new ErrorInfo(item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		Person personDetails= new Person(item.getId(), firstName, lastName, gender, age);
		log.info("Processed Data "+personDetails);
		log.info("Processor Finished");
		return personDetails;
	}

}
