package com.batch.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ErrorInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer errorId;
	private Integer person_id;
	private String error_column;
	private String error_message;
	public Integer getErrorId() {
		return errorId;
	}
	public void setErrorId(Integer errorId) {
		this.errorId = errorId;
	}
	public Integer getPerson_id() {
		return person_id;
	}
	public void setPerson_id(Integer person_id) {
		this.person_id = person_id;
	}
	public String getError_column() {
		return error_column;
	}
	public void setError_column(String error_column) {
		this.error_column = error_column;
	}
	public String getError_message() {
		return error_message;
	}
	public void setError_message(String error_message) {
		this.error_message = error_message;
	}
	public ErrorInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ErrorInfo(Integer person_id, String error_column, String error_message) {
		super();
		this.person_id = person_id;
		this.error_column = error_column;
		this.error_message = error_message;
	}
	
}
