package com.batch.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PersonError {
	@Id
	private Integer id;
	private String columnName;
	private String error;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
}
