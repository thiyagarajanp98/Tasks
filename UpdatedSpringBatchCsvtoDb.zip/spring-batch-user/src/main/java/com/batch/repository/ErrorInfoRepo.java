package com.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.batch.model.ErrorInfo;

public interface ErrorInfoRepo extends JpaRepository<ErrorInfo, Integer>{

}
