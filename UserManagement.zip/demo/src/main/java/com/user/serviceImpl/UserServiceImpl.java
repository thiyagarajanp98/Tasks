package com.user.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.model.UserModel;
import com.user.repository.UserRepository;
import com.user.service.UserService;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserRepository userrepo;
	private boolean f;

	@Override
	public UserModel CreateorUpdate(UserModel model) {
		UserModel userModel=convertDtotoModel(model);
		return userrepo.save(userModel);
	}

	private UserModel convertDtotoModel(UserModel model) {
		UserModel userModel=new UserModel();
		if(model.getId()!=0)
		{
			userModel.setId(model.getId());
		}
		userModel.setFirstName(model.getFirstName());
		userModel.setLastName(model.getLastName());
		userModel.setGender(model.getGender());
		userModel.setAge(model.getAge());
		return userModel;
		
	}

	@Override
	public Boolean Delete(Long id) {
		UserModel model = userrepo.findById(id).get();
		if(model != null) {
			userrepo.deleteById(id);
			return true;
		}
		else
		return false;
		
	}

	@Override
	public List<UserModel> GetAll() {
		List<UserModel> usermodel=userrepo.findAll();
		return usermodel;
		
	}

	@Override
	public List<UserModel> GeUserbyAge(int age) {
		
		return userrepo.GetbyAge(age);
	}

}
