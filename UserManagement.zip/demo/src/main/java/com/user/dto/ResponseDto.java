package com.user.dto;

import java.util.List;

public class ResponseDto<UserModel> {
	private String Message;
	private List<UserModel> Listobj;
	
	public List<UserModel> getListobj() {
		return Listobj;
	}

	public void setListobj(List<UserModel> listobj) {
		Listobj = listobj;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
