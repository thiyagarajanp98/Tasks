package com.user.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.user.dto.ResponseDto;
import com.user.model.UserModel;
import com.user.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping(value = "/create", produces = { "application/json" })
	public ResponseEntity<String> createUser(@RequestBody UserModel model) {
		ResponseDto responseDto = new ResponseDto();
		if (model != null) {
			UserModel userModel = userService.CreateorUpdate(model);
			if (userModel != null) {
				responseDto.setMessage("Successfully created");
				return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);
			}
		} else
			responseDto.setMessage("failed ");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);

	}

	@PostMapping(value = "/update", produces = { "application/json" })
	public ResponseEntity<String> updateUser(@RequestBody UserModel model) {
		ResponseDto responseDto = new ResponseDto();
		if (model != null) {
			UserModel userModel = userService.CreateorUpdate(model);
			if (userModel != null) {
				responseDto.setMessage("Successfully Updated");
				return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);
			}
		} else

			responseDto.setMessage("Failed");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);

	}

	@GetMapping("/listall")
	public ResponseEntity<String> getall() {
		ResponseDto responseDto = new ResponseDto();
		List<UserModel> list = userService.GetAll();
		if (list != null) {
			responseDto.setListobj(list);
			responseDto.setMessage("List retrived");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);

		} else
			responseDto.setMessage("Failed");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);
	}

	@GetMapping("/delete/{id}")
	public ResponseEntity<String> deletebyid(@PathVariable Long id) {
		ResponseDto responseDto = new ResponseDto();
		if (userService.Delete(id)) {
			responseDto.setMessage("Successfully Deleted");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);
		} else
			responseDto.setMessage("Failed");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);

	}

	@GetMapping("/getbyage/{age}")
	public ResponseEntity<String> getbyage(@PathVariable int age) {
		ResponseDto responseDto = new ResponseDto();
		List<UserModel> list =  userService.GeUserbyAge(age);
		if (list != null) {
			responseDto.setListobj(list);
			responseDto.setMessage("List retrived ");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);

		} else
			responseDto.setMessage("Failed");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);
	}
}