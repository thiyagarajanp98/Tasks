package com.user.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.user.dto.ResponseDto;
import com.user.model.UserModel;
import com.user.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;

	private static final Logger log = LoggerFactory.getLogger(UserController.class);

	@PostMapping(value = "/create", produces = { "application/json" })
	public ResponseEntity<String> createUser(@RequestBody UserModel model) {
		log.info("Starting the crete userAPI");
		log.debug("Starting the create userAPI in debug");
		ResponseDto responseDto = new ResponseDto();
		boolean status = userService.Create(model);
		if (status) {
			responseDto.setMessage("Successfully Created");
			log.info("Finishning create userAPI ");
			log.debug("Finishning create userAPI in debug");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);
		} else
			responseDto.setMessage("failed ");
		log.info("Finishning create userAPI ");
		log.debug("Finishning create userAPI in debug");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);

	}

	@PostMapping(value = "/update", produces = { "application/json" })
	public ResponseEntity<String> updateUser(@RequestBody UserModel model) {
		log.info("Starting the update userAPI");
		log.debug("Starting the update userAPI in debug");
		ResponseDto responseDto = new ResponseDto();
		boolean status = userService.Update(model);
		if (status) {
			responseDto.setMessage("Successfully Updated");
			log.info("Finishning update userAPI ");
			log.debug("Finishning update userAPI in debug");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);
		} else
			responseDto.setMessage("failed ");
		log.info("Finishning update userAPI ");
		log.debug("Finishning update userAPI in debug");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);

	}

	@GetMapping(value = "/listall", produces = { "application/json" })
	public ResponseEntity<String> getAll() {
		log.info("Starting the GetAll userAPI");
		log.debug("Starting the GetAll userAPI in debug");
		ResponseDto responseDto = new ResponseDto();
		List<UserModel> list = userService.GetAll();
		if (list.size() != 0) {
			responseDto.setListobj(list);
			responseDto.setMessage("List retrived");
			log.info("Finishning GetAll userAPI ");
			log.debug("Finishning GetAll userAPI in debug");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);

		} else
			responseDto.setMessage("Failed");
		log.info("Finishning GetAll userAPI ");
		log.debug("Finishning GetAll userAPI in debug");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);
	}

	@GetMapping(value = "/delete/{id}", produces = { "application/json" })
	public ResponseEntity<String> deleteById(@PathVariable Long id) {
		log.info("Starting the delete userAPI");
		log.debug("Starting the delete userAPI in debug");
		ResponseDto responseDto = new ResponseDto();
		if (userService.Delete(id)) {
			responseDto.setMessage("Successfully Deleted");
			log.info("Finishning delete userAPI ");
			log.debug("Finishning delete userAPI in debug");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);
		} else
			responseDto.setMessage("Failed");
		log.info("Finishning delete userAPI ");
		log.debug("Finishning delete userAPI in debug");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);

	}

	@GetMapping(value = "/getbyage/{age}", produces = { "application/json" })
	public ResponseEntity<String> getByAge(@PathVariable int age) {
		log.info("Starting the GetByAge userAPI");
		log.debug("Starting the GetByAge userAPI in debug");
		ResponseDto responseDto = new ResponseDto();
		List<UserModel> list = userService.GeUserbyAge(age);
		if (list.size() != 0) {
			responseDto.setListobj(list);
			responseDto.setMessage("List retrived ");
			log.info("Finishning GetByAge userAPI ");
			log.debug("Finishning GetByAge userAPI in debug");
			return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.OK);

		} else
			responseDto.setMessage("Failed");
		log.info("Finishning GetByAge userAPI ");
		log.debug("Finishning GetByAge userAPI in debug");
		return new ResponseEntity<String>(new Gson().toJson(responseDto), HttpStatus.PARTIAL_CONTENT);
	}
}