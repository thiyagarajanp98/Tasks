package com.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.user.model.UserModel;

@Service
public interface UserService {
	
	public Boolean Create(UserModel model);
	public Boolean Update(UserModel model);
	public Boolean Delete(Long id);
	public List<UserModel> GetAll();
	public List<UserModel>GeUserbyAge(int age);
}

