package com.user.dto;

import java.util.List;

import com.user.model.UserModel;

public class ResponseDto {
	private String Message;
	private List<UserModel> Listobj;
	
	public List<UserModel> getListobj() {
		return Listobj;
	}

	public void setListobj(List<UserModel> listobj) {
		Listobj = listobj;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
