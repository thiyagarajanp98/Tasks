package com.user.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.Controller.UserController;
import com.user.model.UserModel;
import com.user.repository.UserRepository;
import com.user.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepo;

	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Override
	public Boolean Create(UserModel model) {
		log.info("Starting the create service ");
		log.debug("Starting the create service in debug");
		if (model.getId() != 0) {
			log.info("Finishning the create service ");
			log.debug("Finishning the create service in debug");
			return false;
		} else if (model.getFirstName() != null && model.getLastName() != null && model.getGender() != null
				&& model.getAge() != 0) {
			userRepo.save(model);
			log.info("Finishning the create service ");
			log.debug("Finishning the create service in debug");
			return true;
		} else
			log.info("Finishning the create service ");
		log.debug("Finishning the create service in debug");
		return false;
	}

	public Boolean Update(UserModel model) {
		log.info("Starting the update service ");
		log.debug("Starting the update service in debug");
		UserModel userModel = Check(model);
		if (userModel.getFirstName() != null && userModel.getLastName() != null && userModel.getGender() != null
				&& userModel.getAge() != 0) {
			userRepo.save(userModel);
			log.info("Finishning the update service ");
			log.debug("Finishning the update service in debug");
			return true;
		} else
			log.info("Finishning the update service ");
		log.debug("Finishning the update service in debug");
		return false;
	}

	private UserModel Check(UserModel model) {
		log.info("Starting the id check for update service ");
		log.debug("Starting the id check for update service in debug");
		Boolean flag = true;
		if (userRepo.existsById(model.getId())) {
			flag = true;
		} else {
			flag = false;
		}
		UserModel userModel = new UserModel();
		if (flag) {
			userModel.setId(model.getId());
			userModel.setFirstName(model.getFirstName());
			userModel.setLastName(model.getLastName());
			userModel.setGender(model.getGender());
			userModel.setAge(model.getAge());
		}
		log.info("Finishning the id check for update service ");
		log.debug("Finishning the id check for update service in debug");
		return userModel;

	}

	@Override
	public Boolean Delete(Long id) {
		log.info("Starting the delete service ");
		log.debug("Starting the delete service in debug");
		Boolean flag = false;
		if (userRepo.existsById(id)) {
			userRepo.deleteById(id);
			flag = true;
		}
		log.info("Finishning delete service ");
		log.debug("Finishning delete service in debug");
		return flag;
	}

	@Override
	public List<UserModel> GetAll() {
		log.info("Starting the GetAll service ");
		log.debug("Starting the GetAll service in debug");
		List<UserModel> usermodel = userRepo.findAll();
		log.info("Finishning GetAll service ");
		log.debug("Finishning GetAll service in debug");
		return usermodel;

	}

	@Override
	public List<UserModel> GeUserbyAge(int age) {
		log.info("Starting the GetByAge service ");
		log.debug("Starting the GetByAge service in debug");
		log.info("Finishning GetByAge service ");
		log.debug("Finishning GetByAge service in debug");
		return userRepo.GetbyAge(age);
	}

}
