package com.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.user.model.UserModel;
@Repository
public interface UserRepository extends JpaRepository<UserModel, Long>{
	@Query("SELECT u FROM UserModel u where age>?1")
	List<UserModel>GetbyAge(int age);
	
	//@Query("select a from AccessHistory a where usertype = ?1 order by id desc ")
}
