package com.batch;

import static org.junit.Assert.*;

import org.junit.Test;

import com.batch.processor.PersonItemProcessor;

public class CheckLastName {

	@Test
	public void test() {
		PersonItemProcessor processor=new PersonItemProcessor();
		boolean result=processor.checkLastName("Peter");
		assertEquals(true,result);
	}

}
