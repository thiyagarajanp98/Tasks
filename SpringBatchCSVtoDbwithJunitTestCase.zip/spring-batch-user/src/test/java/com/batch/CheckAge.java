package com.batch;

import static org.junit.Assert.*;

import org.junit.Test;

import com.batch.processor.PersonItemProcessor;

public class CheckAge {

	@Test
	public void test() {
		PersonItemProcessor processor=new PersonItemProcessor();
		boolean result=processor.checkAge("23");
		assertEquals(true,result);
	}

}
