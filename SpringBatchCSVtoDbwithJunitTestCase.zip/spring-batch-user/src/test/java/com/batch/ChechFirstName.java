package com.batch;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.batch.processor.PersonItemProcessor;

public class ChechFirstName {

	@Test
	public void test() {
		PersonItemProcessor processor=new PersonItemProcessor();
		boolean result=processor.checkFirstName("Peter");
		assertEquals(true,result);
	}

}
