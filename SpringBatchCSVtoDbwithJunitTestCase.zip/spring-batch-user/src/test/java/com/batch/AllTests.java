package com.batch;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ChechFirstName.class, CheckAge.class, CheckGender.class, CheckLastName.class })
public class AllTests {

}
