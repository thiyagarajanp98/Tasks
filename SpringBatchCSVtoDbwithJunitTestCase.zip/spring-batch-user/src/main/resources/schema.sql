  
DROP TABLE IF EXISTS person_error;


CREATE TABLE person_error  (
    id BIGINT auto_increment NOT NULL PRIMARY KEY,
    column_name VARCHAR(40),
    error VARCHAR(40)
    
);
INSERT INTO `userbatch`.`person_error` ( `column_name`, `error`) VALUES ( 'FirstName', 'Should not contain any number');
INSERT INTO `userbatch`.`person_error` (`column_name`, `error`) VALUES ('LastName', 'Should not contain any number');
INSERT INTO `userbatch`.`person_error` ( `column_name`, `error`) VALUES ('Age', 'Should contain only number');
INSERT INTO `userbatch`.`person_error` ( `column_name`, `error`) VALUES ( 'Gender', 'Should contain only Male or Female');
