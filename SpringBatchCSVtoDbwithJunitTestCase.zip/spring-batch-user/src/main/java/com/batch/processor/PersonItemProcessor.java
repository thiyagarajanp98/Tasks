package com.batch.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.batch.model.ErrorInfo;
import com.batch.model.Person;
import com.batch.model.PersonError;
import com.batch.repository.ErrorInfoRepo;
import com.batch.repository.PersonErrorRepo;

public class PersonItemProcessor implements ItemProcessor<Person, Person>{

	private static final Logger log= LoggerFactory.getLogger(PersonItemProcessor.class);
	@Autowired
	PersonErrorRepo personErrorRepo;
	@Autowired
	ErrorInfoRepo errorInfoRepo;
	String firstName="";
	String lastName="";
	String age="";
	String gender="";
	@Override
	public Person process(Person item) throws Exception {
		log.info("Processor Started");
		if(!checkFirstName(item.getFirstName())) {
			PersonError details=personErrorRepo.findByColumnName("FirstName");
			ErrorInfo error=new ErrorInfo(item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		if(!checkLastName(item.getLastName())) {
			PersonError details=personErrorRepo.findByColumnName("LastName");
			ErrorInfo error=new ErrorInfo( item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		if(!checkAge(item.getAge())) {
			PersonError details=personErrorRepo.findByColumnName("Age");
			ErrorInfo error=new ErrorInfo(item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		if(!checkGender(item.getGender())) {
			PersonError details=personErrorRepo.findByColumnName("Gender");
			ErrorInfo error=new ErrorInfo(item.getId(), details.getColumnName(), details.getError());
			errorInfoRepo.save(error);
		}
		Person personDetails= new Person(item.getId(), firstName, lastName, gender, age);
		log.info("Processed Data "+personDetails);
		log.info("Processor Finished");
		 firstName=firstName.replaceAll(firstName, "");
		 lastName=lastName.replaceAll(lastName, "");
		 age=age.replaceAll(age, "");
		 gender=gender.replaceAll(gender, "");
		return personDetails;
	}
	public boolean checkFirstName(String name) {
		if(name.matches("^[a-zA-Z]*$")){
			firstName+=name.toUpperCase();
			return true;
		}
		else {
		return false;
		}
	}
	public boolean checkLastName(String name) {
		if(name.matches("^[a-zA-Z]*$")){
			lastName+=name.toUpperCase();
			return true;
		}
		else {
		return false;
		}
	}
	public boolean checkAge(String name) {
		if(name.matches("^[0-9]*$")&&name.length()<3){
			age+=name;
			return true;
		}
		else {
		return false;
		}
	}
	public boolean checkGender(String name) {
		if(name.equals("MALE")||name.equals("male")||name.equals("Male")||name.equals("FEMALE")||name.equals("Female")||name.equals("female")){
			gender+=name.toUpperCase();
			return true;
		}
		else {
		return false;
		}
	}
	
}
