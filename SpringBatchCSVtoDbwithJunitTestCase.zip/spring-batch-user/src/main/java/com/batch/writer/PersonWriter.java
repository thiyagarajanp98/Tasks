package com.batch.writer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.batch.model.Person;
import com.batch.repository.PersonRepo;

public class PersonWriter implements ItemWriter<Person>{
	private static final Logger log=LoggerFactory.getLogger(PersonWriter.class);
	@Autowired
	private PersonRepo personRepo;
	@Override
	public void write(List<? extends Person> items) throws Exception {
		log.info("Writter Started");
		for(Person list:items)
		{
			if(!list.getFirstName().isEmpty()&&!list.getLastName().isEmpty()&&!list.getGender().isEmpty()&&!list.getAge().isEmpty())
			{
				personRepo.save(list);
			}
		}
		log.info("Writter Finished");
	}

}
