package com.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.batch.model.Person;

public interface PersonRepo extends JpaRepository<Person, Integer>{

}
