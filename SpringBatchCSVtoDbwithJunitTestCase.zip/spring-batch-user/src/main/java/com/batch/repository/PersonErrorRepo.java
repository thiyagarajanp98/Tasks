package com.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.batch.model.PersonError;

public interface PersonErrorRepo extends JpaRepository<PersonError, Integer>{
	
	public PersonError findByColumnName(String value);
}
